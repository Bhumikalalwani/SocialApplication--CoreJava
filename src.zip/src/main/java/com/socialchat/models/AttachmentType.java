package com.socialchat.models;

public enum AttachmentType {
    IMAGE,
    VIDEO,
    FILE
}
