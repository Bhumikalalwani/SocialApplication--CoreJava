package com.socialchat.models;

public class NormalUser extends User {
    public NormalUser(String id, String username, String displayName) {
        super(id, username, displayName);
    }
}
