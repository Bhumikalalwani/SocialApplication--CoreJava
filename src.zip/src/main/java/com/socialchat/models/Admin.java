package com.socialchat.models;

public class Admin extends User {
    public Admin(String id, String username, String displayName) {
        super(id, username, displayName);
    }
}
