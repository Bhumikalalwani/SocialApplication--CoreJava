package com.socialchat;

import com.socialchat.models.*;
import com.socialchat.services.*;
import com.socialchat.storage.Database;

import java.util.List;
import java.util.Scanner;

public class Menu {
    private final Scanner scanner = new Scanner(System.in);

    private final NotificationService notifications = new NotificationService();
    private final UserService userService = new UserService();
    private final ChatService chatService = new ChatService(notifications);
    private final PostService postService = new PostService(notifications);
    private final MomentService momentService = new MomentService();
    private final StoryService storyService = new StoryService();
    private final SearchService searchService = new SearchService();

    public void start() {
        Database.getInstance().seedDemoData(); // preload Alice + Bob

        notifications.subscribe(event -> System.out.println("[NOTIFY] " + event));

        boolean running = true;
        while (running) {
            printMenu();
            String choice = scanner.nextLine();

            switch (choice) {
                case "1" -> registerUser();
                case "2" -> sendDirectMessage();
                case "3" -> createGroup();
                case "4" -> createPost();
                case "5" -> search();
                case "6" -> viewMomentsAndStories();
                case "0" -> running = false;
                default -> System.out.println("Invalid choice.");
            }
        }
        System.out.println("👋 Exiting SocialChat...");
    }

    private void printMenu() {
        System.out.println("\n===== SOCIALCHAT MENU =====");
        System.out.println("1. Register User");
        System.out.println("2. Send Direct Message");
        System.out.println("3. Create Group & Send Message");
        System.out.println("4. Create Post (Text/Moment/Story)");
        System.out.println("5. Search (Users/Groups/Posts/Messages)");
        System.out.println("6. View Feed (Moments + Stories)");
        System.out.println("0. Exit");
        System.out.print("Choose an option: ");
    }

    // --- Menu Actions ---
    private void registerUser() {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter display name: ");
        String display = scanner.nextLine();

        NormalUser user = userService.registerNormal(username, display);
        System.out.println("✅ Registered user: " + user.getUsername());
    }

    private void sendDirectMessage() {
        System.out.print("Sender ID: ");
        String from = scanner.nextLine();
        System.out.print("Recipient ID: ");
        String to = scanner.nextLine();
        System.out.print("Message: ");
        String text = scanner.nextLine();

        chatService.sendDirectText(from, to, text);
        System.out.println("✅ Message sent.");
    }

    private void createGroup() {
        System.out.print("Owner ID: ");
        String owner = scanner.nextLine();
        System.out.print("Group name: ");
        String name = scanner.nextLine();

        Group group = chatService.createGroup(owner, name);
        System.out.println("✅ Group created with ID: " + group.getId());
    }

    private void createPost() {
        System.out.println("Choose post type: 1) Text  2) Moment  3) Story");
        String type = scanner.nextLine();

        System.out.print("Author ID: ");
        String userId = scanner.nextLine();
        System.out.print("Content: ");
        String content = scanner.nextLine();

        switch (type) {
            case "1" -> postService.createTextPost(userId, content);
            case "2" -> momentService.createMoment(userId, content);
            case "3" -> storyService.createStory(userId, content);
            default -> System.out.println("Invalid post type.");
        }
    }

    private void search() {
        System.out.println("Search: 1) Users  2) Groups  3) Posts  4) Messages");
        String type = scanner.nextLine();

        System.out.print("Enter query: ");
        String query = scanner.nextLine();

        switch (type) {
            case "1" -> searchService.searchUsers(query).forEach(u ->
                    System.out.println("User: " + u.getUsername()));
            case "2" -> searchService.searchGroups(query).forEach(g ->
                    System.out.println("Group: " + g.getName()));
            case "3" -> searchService.searchPosts(query).forEach(p ->
                    System.out.println("Post: " + p.render()));
            case "4" -> searchService.searchMessages(query).forEach(m ->
                    System.out.println("Message: " + m.render()));
            default -> System.out.println("Invalid search type.");
        }
    }

    private void viewMomentsAndStories() {
        Database.getInstance().getUsers().values().forEach(user -> {
            System.out.println("\n--- Feed for " + user.getUsername() + " ---");
            System.out.println("Moments:");
            momentService.getMomentsForUser(user.getId()).forEach(mp ->
                    System.out.println("  " + mp.render()));

            System.out.println("Stories:");
            storyService.getActiveStories(user.getId()).forEach(st ->
                    System.out.println("  Story: " + st.getContent()));
        });
    }
}
