package com.socialchat.storage;

import com.socialchat.models.*;

import java.util.HashMap;
import java.util.Map;

public class Database {
    private static Database instance;

    private final Map<String, User> users = new HashMap<>();
    private final Map<String, Group> groups = new HashMap<>();
    private final Map<String, Post> posts = new HashMap<>();
    private final Map<String, Message> messages = new HashMap<>();
    private final Map<String, Attachment> attachments = new HashMap<>();

    private Database() {}

    public static synchronized Database getInstance() {
        if (instance == null) {
            instance = new Database();
        }
        return instance;
    }

    // --- GETTERS ---
    public Map<String, User> getUsers() { return users; }
    public Map<String, Group> getGroups() { return groups; }
    public Map<String, Post> getPosts() { return posts; }
    public Map<String, Message> getMessages() { return messages; }
    public Map<String, Attachment> getAttachments() { return attachments; }

    // --- Reset (for testing/demo) ---
    public void reset() {
        users.clear();
        groups.clear();
        posts.clear();
        messages.clear();
        attachments.clear();
    }

    // --- Seed some demo data ---
    public void seedDemoData() {
        reset();
        // Add 2 demo users
        NormalUser alice = new NormalUser("u1", "alice", "Alice Wonderland");
        NormalUser bob = new NormalUser("u2", "bob", "Bob Builder");

        users.put(alice.getId(), alice);
        users.put(bob.getId(), bob);
    }
}
